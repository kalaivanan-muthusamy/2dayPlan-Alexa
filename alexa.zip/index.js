const routes = require('./routes')

exports.handler = routes
