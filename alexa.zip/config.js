const config = () => {
  return {
    'mongoURL' : 'const uri = "mongodb+srv://mileStone:mileStone%40123%23@cluster0-xqeta.mongodb.net/test?retryWrites=true&w=majority";'
  }
}

module.exports = config;
