const config = {
  "mongoURL" : "mongodb+srv://mileStone:mileStone%40123%23@cluster0-xqeta.mongodb.net/mileStone?retryWrites=true&w=majority"
}

module.exports = config;
