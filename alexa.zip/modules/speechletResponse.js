const speechletResponse = (outputText, shouldEndSession) => {
  return {
    outputSpeech: {
      type: "PlainText",
      text: outputText,
      debugMe: 'hello',
    },

    shouldEndSession: shouldEndSession
  }
}

module.exports = speechletResponse
