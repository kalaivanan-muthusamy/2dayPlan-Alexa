const response = (speechletResponse) => {
  return {
    version: "1.0",
    response: speechletResponse
  }
}

module.exports = response
